import "./App.css";
import ImageUpload from "./components/ImageUpload";
function App() {
  return (
    <div>
      <ImageUpload />
    </div>
  );
}

export default App;
